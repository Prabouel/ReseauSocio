# MISSION RÉSEAUX - Jeu pédagogique Ren'Py pour collégiens

init -2 python:
    config.screen_width = 1280
    config.screen_height = 720

define e = Character("Élève", color="#9fe8ff")
define n = Character(None)
default score = 0
default erreurs = 0
default niveau = 1
default use_sfx = True
default use_music = True

init python:
    import random
    def shuffled_menu(choices):
        result = list(choices)
        random.shuffle(result)
        return result
    def play_optional_sound(filename):
        if use_sfx and renpy.loadable(filename):
            renpy.sound.play(filename)
    def start_optional_music(filename):
        if use_music and renpy.loadable(filename):
            renpy.music.play(filename, loop=True, fadein=1.5)
    def stop_optional_music():
        renpy.music.stop(fadeout=1.0)

image bg mission = im.Scale("images/background.png", 1280, 720)
image logo mission = im.Scale("images/logo.png", 900, 323)

style say_dialogue:
    size 25
style say_label:
    size 26

screen choice(items):
    style_prefix "choice"
    vbox:
        xalign 0.5
        yalign 0.62
        xsize 1020
        spacing 10
        for i in items:
            textbutton i.caption:
                action i.action
                xsize 1020
                xpadding 24
                ypadding 12
                text_size 22
                text_text_align 0.5
                text_xalign 0.5

screen hud():
    frame:
        xalign 0.02
        yalign 0.02
        padding (12, 8)
        background "#07162ccc"
        text "Score : [score]/4   Erreurs : [erreurs]   Niveau : [niveau]/4" size 19 color "#ffffff"

screen card(txt):
    modal True
    frame:
        xalign 0.5
        yalign 0.5
        xsize 1040
        xmaximum 1040
        ymaximum 610
        padding (28, 22)
        background "#07162cee"
        vbox:
            xfill True
            spacing 18
            text txt:
                size 24
                xmaximum 970
                xalign 0.5
                text_align 0.5
                color "#ffffff"
            textbutton "CONTINUER":
                action Return()
                xalign 0.5
                text_size 21

screen audio_settings():
    frame:
        xalign 0.98
        yalign 0.02
        padding (10, 6)
        background "#07162ccc"
        hbox:
            spacing 7
            text "Effets" size 16
            textbutton ("ON" if use_sfx else "OFF"):
                action ToggleVariable("use_sfx")
                text_size 16
            text "Musique" size 16
            textbutton ("ON" if use_music else "OFF"):
                action [ToggleVariable("use_music"), Function(renpy.music.set_pause, use_music)]
                text_size 16

label start:
    $ score = 0
    $ erreurs = 0
    $ niveau = 1
    scene bg mission
    show screen hud
    show screen audio_settings
    $ start_optional_music("audio/theme.ogg")
    show logo mission at truecenter
    with dissolve
    $ renpy.pause(2.0)
    hide logo mission
    with dissolve
    call screen card("Bienvenue dans MISSION RÉSEAUX !\n\nApprends à publier avec prudence, protéger ton compte et garder le contrôle de tes usages.\n\nQuatre situations t'attendent.")
    jump question1

label question1:
    $ niveau = 1
    scene bg mission
    show screen hud
    show screen audio_settings
    $ play_optional_sound("audio/level.ogg")
    n "Niveau 1 - La photo du groupe"
    n "Après une sortie, tu veux publier une photo amusante sur laquelle plusieurs camarades sont reconnaissables."
    e "Que fais-tu avant de la publier ?"
    $ opts = shuffled_menu([
        ("Je la publie : c'est moi qui ai pris la photo", "q1_r1"),
        ("Je demande l'accord des personnes reconnaissables", "q1_r2"),
        ("Je la publie seulement pendant quelques heures", "q1_r3"),
    ])
    menu:
        "[opts[0][0]]":
            jump expression opts[0][1]
        "[opts[1][0]]":
            jump expression opts[1][1]
        "[opts[2][0]]":
            jump expression opts[2][1]

label q1_r1:
    $ erreurs += 1
    $ play_optional_sound("audio/error.ogg")
    n "Prendre une photo ne donne pas automatiquement le droit de publier l'image des autres."
    jump q1_explication

label q1_r2:
    $ score += 1
    $ play_optional_sound("audio/correct.ogg")
    n "Exact : chacun doit pouvoir décider de la diffusion de son image."
    jump q1_explication

label q1_r3:
    $ erreurs += 1
    $ play_optional_sound("audio/error.ogg")
    n "Même temporaire, une publication peut être enregistrée ou partagée."
    jump q1_explication

label q1_explication:
    call screen card("À RETENIR\n\nAvant de publier une personne reconnaissable, demande son accord. Une image peut être copiée, capturée et diffusée au-delà du public prévu.")
    jump question2

label question2:
    $ niveau = 2
    scene bg mission
    show screen hud
    show screen audio_settings
    $ play_optional_sound("audio/level.ogg")
    n "Niveau 2 - La demande d'un inconnu"
    n "Un compte inconnu t'envoie une demande, te pose des questions personnelles et veut poursuivre la conversation en privé."
    e "Quel réflexe adopter ?"
    $ opts = shuffled_menu([
        ("Accepter pour ne pas paraître impoli", "q2_r1"),
        ("Ne pas donner d'informations, bloquer ou signaler si nécessaire et en parler à un adulte en cas de doute", "q2_r2"),
        ("Envoyer une photo pour vérifier que la personne est sympathique", "q2_r3"),
    ])
    menu:
        "[opts[0][0]]":
            jump expression opts[0][1]
        "[opts[1][0]]":
            jump expression opts[1][1]
        "[opts[2][0]]":
            jump expression opts[2][1]

label q2_r1:
    $ erreurs += 1
    $ play_optional_sound("audio/error.ogg")
    n "Tu n'as aucune obligation d'accepter un inconnu ni de répondre à ses questions."
    jump q2_explication

label q2_r2:
    $ score += 1
    $ play_optional_sound("audio/correct.ogg")
    n "Très bon réflexe : tu protèges tes informations et demandes de l'aide si la situation t'inquiète."
    jump q2_explication

label q2_r3:
    $ erreurs += 1
    $ play_optional_sound("audio/error.ogg")
    n "Une photo donne davantage d'informations sans prouver l'identité de l'autre compte."
    jump q2_explication

label q2_explication:
    call screen card("À RETENIR\n\nUn profil ne prouve pas l'identité d'une personne. Limite les contacts inconnus, protège tes informations et demande conseil à un adulte de confiance.")
    jump question3

label question3:
    $ niveau = 3
    scene bg mission
    show screen hud
    show screen audio_settings
    $ play_optional_sound("audio/level.ogg")
    n "Niveau 3 - La course aux réactions"
    n "Une publication reçoit peu de réactions. Tu as envie de la consulter sans cesse et d'en publier une autre plus provocante."
    e "Quelle décision te permet de garder le contrôle ?"
    $ opts = shuffled_menu([
        ("Publier quelque chose de choquant pour obtenir plus de réactions", "q3_r1"),
        ("Faire une pause et se rappeler que les réactions ne mesurent pas sa valeur", "q3_r2"),
        ("Actualiser l'écran jusqu'à recevoir suffisamment de réactions", "q3_r3"),
    ])
    menu:
        "[opts[0][0]]":
            jump expression opts[0][1]
        "[opts[1][0]]":
            jump expression opts[1][1]
        "[opts[2][0]]":
            jump expression opts[2][1]

label q3_r1:
    $ erreurs += 1
    $ play_optional_sound("audio/error.ogg")
    n "Chercher à tout prix des réactions peut conduire à publier un contenu que l'on regrettera."
    jump q3_explication

label q3_r2:
    $ score += 1
    $ play_optional_sound("audio/correct.ogg")
    n "Exact : tu décides de ton usage au lieu de laisser les notifications décider pour toi."
    jump q3_explication

label q3_r3:
    $ erreurs += 1
    $ play_optional_sound("audio/error.ogg")
    n "Cette répétition entretient la pression et détourne l'attention."
    jump q3_explication

label q3_explication:
    call screen card("À RETENIR\n\nLes plateformes utilisent les notifications et recommandations pour retenir l'attention. Coupe-les si nécessaire et choisis des moments précis pour consulter.")
    jump question4

label question4:
    $ niveau = 4
    scene bg mission
    show screen hud
    show screen audio_settings
    $ play_optional_sound("audio/level.ogg")
    n "Niveau 4 - La moquerie virale"
    n "Une vidéo ridiculisant un élève circule dans un groupe. Beaucoup ajoutent des commentaires moqueurs."
    e "Quelle est la meilleure réaction ?"
    $ opts = shuffled_menu([
        ("Ajouter une réaction sans commentaire", "q4_r1"),
        ("Ne pas relayer, conserver une preuve, soutenir l'élève et prévenir un adulte", "q4_r2"),
        ("Transférer la vidéo à un autre groupe pour demander son avis", "q4_r3"),
    ])
    menu:
        "[opts[0][0]]":
            jump expression opts[0][1]
        "[opts[1][0]]":
            jump expression opts[1][1]
        "[opts[2][0]]":
            jump expression opts[2][1]

label q4_r1:
    $ erreurs += 1
    $ play_optional_sound("audio/error.ogg")
    n "Même une simple réaction augmente la visibilité et peut encourager la diffusion."
    jump q4_explication

label q4_r2:
    $ score += 1
    $ play_optional_sound("audio/correct.ogg")
    n "Excellent : tu limites la diffusion et aides la personne visée."
    jump q4_explication

label q4_r3:
    $ erreurs += 1
    $ play_optional_sound("audio/error.ogg")
    n "Cela continue la diffusion du contenu humiliant."
    jump q4_explication

label q4_explication:
    call screen card("À RETENIR\n\nNe participe pas à l'humiliation. Garde une preuve sans la rediffuser, utilise le signalement, soutiens la victime et préviens rapidement un adulte.")
    jump bilan_final

label bilan_final:
    scene bg mission
    show screen hud
    show screen audio_settings
    $ play_optional_sound("audio/victory.ogg")
    if score == 4:
        $ msg = "EXPERT : tu as acquis les quatre bons réflexes !"
    elif score >= 2:
        $ msg = "BON NIVEAU : encore quelques réflexes à consolider."
    else:
        $ msg = "EN APPRENTISSAGE : le débrief va t'aider à progresser."
    call screen card("BILAN DE LA MISSION\n\nScore : [score] / 4     Erreurs : [erreurs]\n\n[msg]\n\nLES 4 RÉFLEXES\n1. Image : demander l'accord avant de publier.\\n2. Compte : limiter les informations et les contacts.\\n3. Attention : ne pas laisser les réactions décider pour soi.\\n4. Respect : ne pas relayer, soutenir et signaler.")
    menu:
        "Rejouer":
            jump start
        "Quitter":
            $ stop_optional_music()
            $ renpy.quit()
